# SESSDSA18课程上机作业
# 【H6】线性表与链式存储结构编程作业
#
# 说明：为方便批改作业，请同学们在完成作业时注意并遵守下面规则：
# （1）直接在本文件中的函数体内编写代码，每个题目的函数后有调用语句用于检验，
# 上交作业时提交本文件，命名为h6_学号_姓名.py，如h6_1700000012_张三.py
# （2）如果作业中对相关类有明确命名/参数/返回值要求的，请严格按照要求执行
# （3）有些习题会对代码的编写进行特殊限制，请注意这些限制并遵守
# （4）作业在4月10日23：59之前提交到教学网
#
#
# by TYY&ZHD
# 2018.4.2


class Node():
    def __init__(self, initdata=None):
        self.data = initdata
        self.next = None
        self.prev = None

    def getData(self):
        return self.data

    def getNext(self):
        return self.next

    def getPrev(self):
        return self.prev

    def setData(self, newdata):
        self.data = newdata

    def setNext(self, newnext):
        self.next = newnext

    def setPrev(self, newprev):
        self.prev = newprev

# ======== 1 UnorderedList ========
# 用链表实现UnorderedList的如下方法：isEmpty, add, search, size, remove, append，index，pop，insert, __len__, __getitem__
# 用于列表字符串表示的__str__方法 (注：__str__里不要使用str(), 用repr()代替
# 用于切片的__getitem__方法
# 选做：UnorderedList(iterable) -> new UnorderedList initialized from iterable's items
# 选做：__eq__, __iter__
class UnorderedList():
    def __init__(self, argv=None):
        pass

    def isEmpty(self):
        pass

    def add(self, item):
        pass
    
    def search(self, item):
        pass

    def size(self):
        pass

    def remove(self, item):
        pass

    def append(self, item):
        pass

    # 搜索value，从下标start到stop，左闭右开
    def index(self, value, start=0, stop=None):
        if stop is None:
            stop = self.size()
        pass

    def pop(self, pos=-1):
        pass

    def insert(self, pos, item):
        pass

    def __len__(self):
        pass

    def __str__(self):
        return ""

    __repr__ = __str__

    def __getitem__(self, argv):
        #请参考：http://gis4g.pku.edu.cn/python3-slice-getitem/
        #可以不用处理负数
        pass

# 检验
print("======== 1 UnorderedList ========")
mylist = UnorderedList()
for i in range(0, 20, 2):
    mylist.append(i)
mylist.add(3)
mylist.remove(6)
print(mylist.isEmpty())           # False
print(mylist.search(5))           # False
print(mylist.size())              # 10
print(mylist.index(2))            # 2
print(mylist.pop())               # 18
print(mylist.pop(2))              # 2
print(mylist)                     # [3, 0, 4, 8, 10, 12, 14, 16]
mylist.insert(3, "10")
print(len(mylist))                # 9
print(mylist[4])                  # 8
print(mylist[3:8:2])              # ['10', 10, 14]



# ======== 2 OrderedList ========
# 将OrderedList作为UnorderedList的子类来实现
# 实现ADT OrderedList的所有接口:
# add, remove, search, isEmpty, size, index, pop
# 注：不继承insert, append方法
class OrderedList(UnorderedList):
    pass

# 检验
print("======== 2 OrderedList ========")
mylist = OrderedList()
for i in range(0, 10, 2):
    mylist.add(i)
mylist.add(3)
mylist.remove(6)
mylist.add(5)
print(mylist.isEmpty())         # False
print(mylist.search(8))         # True
print(mylist)                   # [0, 2, 3, 4, 5, 8]
print(mylist.pop())             # 8
print(mylist.size())            # 5
print(mylist.index(4))          # 3
print(mylist.pop(-2))           # 4
print(mylist[1:])               # [2, 3, 5]



# ======== 3 ADT Stack & Queue ========
# 用链表实现ADT Stack与ADT Queue的所有接口
class Stack():
    pass

class Queue():
    pass

# 检验
print("======== 3 ADT Stack & Queue ========")
s = Stack()
q = Queue()
for i in range(10):
    s.push(i)
    q.enqueue(i)
print(s.peek(), q.dequeue())      # 9 0
print(s.pop(), q.size())          # 9 9
while not s.isEmpty():
    s.pop()
print(s.size(), q.isEmpty())      # 0 False



# ======== 4 DoublyLinkedList ========
# 实现双向链表版本的UnorderedList，接口同ADT UnorderedList
# 在节点Node中增加prev变量，引用前一个节点
# 在UnorderedList中增加tail变量，引用列表中最后一个节点
# 增加getTail方法
class DoublyLinkedList():
    pass

# 检验
print("======== 4 DoublyLinkedList ========")
mylist = DoublyLinkedList()
for i in range(0, 20, 2):
    mylist.append(i)
mylist.add(3)
mylist.remove(6)
print(mylist.getTail().getPrev().getData())   # 16
print(mylist.isEmpty())                       # False
print(mylist.search(5))                       # False
print(mylist.size())                          # 10
print(mylist.index(2))                        # 2
print(mylist.pop())                           # 18
print(mylist.pop(2))                          # 2
print(mylist)                                 # [3, 0, 4, 8, 10, 12, 14, 16]
mylist.insert(3, "10")
print(len(mylist))                            # 9
print(mylist[4])                              # 8
print(mylist[3:8:2])                          # ['10', 10, 14]
