# SESSDSA18课程上机作业
# 【H9】排序查找编程作业
#
# 说明：为方便批改作业，请同学们在完成作业时注意并遵守下面规则：
# （1）直接在本文件中的函数体内编写代码，每个题目的函数后有调用语句用于检验
# （2）如果作业中对相关类有明确命名/参数/返回值要求的，请严格按照要求执行
# （3）有些习题会对代码的编写进行特殊限制，请注意这些限制并遵守
# （4）作业在5月25日23：59之前提交到作业提交网站

# 划重点：
#### 将本文件与一个说明分析文档共两个文件打包提交，
#### 命名为h9_学号_姓名，如h9_1700000012_张三

#
# by TYY
# 2018.5.15

# =========== 1 无切片的二分搜索 ==========
# 用递归算法实现二分搜索，避免用切片操作。

def binarySearch_noSlice(alist, item):
    pass

# 检验
print(binarySearch_noSlice([1, 2, 3, 4, 5], 5))                                                     # True
print(binarySearch_noSlice([1, 7, 13, 19, 25, 31, 37, 43, 49, 55, 61, 67, 73, 79, 85, 91, 97], 70)) # False
print(binarySearch_noSlice([1, 10, 19, 28, 37, 46, 55, 64, 73, 82, 91, 100, 109, 118, 127, 136, 145, 154, 163, 172, 181, 190, 199, 208, 217,
       226, 235, 244, 253, 262, 271, 280, 289, 298], 233))                                          # False


# =========== 2 ADT Map =================
# 采用数据链(chaining)的冲突解决技术来实现ADT Map，
# 要求实现ADT Map中定义的所有方法：put(key, data), get(key), __delitem__(key), __len(), __contains__(key)

class HashMap_chaining():
    def __init__(self, size=11):
        pass

    def put(self, key, data):
        pass

    def get(self, key):
        pass

    __setitem__ = put
    __getitem__ = get

    def __delitem__(self, key):
        pass

    def __len__(self):
        pass

    def __contains__(self, key):
        pass

# 检验
m = HashMap_chaining()
for i in range(1, 101, 11):
    m[i] = i
print(len(m))
for i in range(1, 101, 22):
    print(m[i], end=' ')
print()
for i in range(1, 101, 22):
    m[i] = i * 2
for i in range(1, 101, 11):
    print(m[i], end=' ')
print()
for i in range(1, 101, 22):
    del m[i]
print(len(m))
for i in range(1, 101, 11):
    print(i in m, end=' ')

# 10
# 1 23 45 67 89
# 2 12 46 34 90 56 134 78 178 100
# 5
# False True False True False True False True False True


# =========== 3 大小自动增长的散列表 =======
# 采用开放定址冲突解决技术的散列表，课件中是固定大小的，如果希望在负载因子达到某个阈值之后，
# 散列表的大小能自动增长，该如何设计算法？
# 请写一个算法说明和分析，并实现之。
class HashTable:
    pass


# =========== 4 取“中值”快排 ==============
# 自行设计一种取“中值”的方法实现快速排序，并与课件中的快速排序比较性能。
# 请写一个算法说明和分析，并实现之。
def quickSort(alist):
    pass
