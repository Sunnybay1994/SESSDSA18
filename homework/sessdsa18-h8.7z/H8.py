# SESSDSA18课程上机作业
# 【H8】动态规划编程作业
#
# 说明：为方便批改作业，请同学们在完成作业时注意并遵守下面规则：
# （1）直接在本文件中的函数体内编写代码，每个题目的函数后有调用语句用于检验，
# 上交作业时提交本文件，命名为h8_学号_姓名.py，如h8_1700000012_张三.py
# （2）如果作业中对相关类有明确命名/参数/返回值要求的，请严格按照要求执行
# （3）有些习题会对代码的编写进行特殊限制，请注意这些限制并遵守
# （4）作业在4月27日23：59之前提交到教学网
#
#
# by TYY&ZHD
# 2018.4.9


# =========== 1 博物馆大盗问题 ===========
# 给定一个宝物列表treasureList = [{'w': 2,'v': 3}, {'w': 3,'v': 4}, ...] 
# 这样treasureList[0]['w']就是第一件宝物的重量，等等
# 给定包裹最多承重maxWeight > 0
# 实现一个函数，根据以上条件得到最高总价值以及对应的宝物
# 参数：宝物列表treasureList，背包最大承重maxWeight
# 返回值：最大总价值maxValue，选取的宝物列表choosenList(格式同treasureList)
def dpMuseumThief(treasureList, maxWeight):
    maxValue = 0
    choosenList = []

    # 在这里补充你的代码

    return maxValue, choosenList

# 检验
print("=========== 1 博物馆大盗问题 ============")
treasureList = [{'w':2, 'v':3}, {'w':3, 'v':4}, {'w':4, 'v':8}, {'w':5, 'v':8}, {'w':9, 'v':10}]
maxValue, choosenList = dpMuseumThief(treasureList, 20)
print(maxValue)         # 29
print(choosenList)      # [{'w':2, 'v':3}, {'w':4, 'v':8}, {'w':5, 'v':8}, {'w':9, 'v':10}]


# ========= 2 单词最小编辑距离问题 =========
# 实现一个函数，给定两个单词，得出从源单词变到目标单词所需要的最小编辑距离，返回总得分与编辑操作过程
# 从源单词每复制一个字母到目标单词，计5分
# 从源单词每删除一个字母，计20分
# 在目标单词每插入一个字母，计20分
# 参数：两个字符串，即源单词original与目标单词target
# 返回值：一个整数与一个列表，最低的分数与操作过程，示例见检验
def dpWordEdit(original, target):
    score = 0
    operations = []

    # 在这里补充你的代码

    return score, operations

# 检验
print("========= 2 单词最小编辑距离问题 =========")
score, operations = dpWordEdit("algorithm", "alligator")
print(score)        # 185
print(operations)   # ['copy a', 'copy l', 'insert l', 'insert i', 'copy g', 'insert a', 'insert t', 'copy o', 'copy r', 'delete i', 'delete t', 'delete h', 'delete m']
